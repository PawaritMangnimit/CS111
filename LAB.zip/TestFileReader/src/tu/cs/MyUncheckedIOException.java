package tu.cs;

//MyUncheckedIOException becomes unchecked exception
public class MyUncheckedIOException extends RuntimeException{

}
