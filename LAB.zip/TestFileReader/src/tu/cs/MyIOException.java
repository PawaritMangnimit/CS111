package tu.cs;

import java.io.File;
import java.util.Date;

//MyIOException becomes a checked exception.
public class MyIOException extends Exception {
	//error message
	//other information เช่น user detail, file, etc
	private Date errorTime ;
	private File errorFile ;
	
	public MyIOException() {
		super();
	}
	
	public MyIOException(String errorMsg, Date errorTime, File errorFile) {
		super(errorMsg);
		this.errorTime = errorTime;
		this.errorFile = errorFile;
	}
	
	
	public Date getErrorTime() {
		return errorTime;
	}
	public File getErrorFile() {
		return errorFile;
	}
	
	
	
	
	
}
