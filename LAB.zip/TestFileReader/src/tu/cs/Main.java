package tu.cs;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws MyIOException {
		File file = new File("C:\\Users\\User\\Downloads\\monsters.txt");
		Scanner scanner = null ;
			try 
			{
				//1. Open File "c:\sample.txt"
				scanner = new Scanner(file);
				//2. Read 1 line and print to console until the end of file
				int numberOfMonsters = scanner.nextInt();
				int i,x=0,y=0;
				String status = null;
				if(numberOfMonsters > 0)
				{
					for(i=1;i<=numberOfMonsters;i++)
					{
						System.out.printf("Monster (%d) : x=%d , y=%d , status:%s",i,x,y,status);
					}
				}
			}
			catch(FileNotFoundException ex) //ใช้แค่ exception ก็ได้ แต่อันนี้เฉพาะไปที่ file not found
			{
				//Handle exception occured in try block.
				//Display warning message to mention that "sample.txt" not existed.
				System.out.println(ex.getMessage());
				MyIOException e = new MyIOException(ex.getMessage(),new Date(),file);
				throw e;
			}
			catch(Exception ex)
			{
				System.out.println(ex.getMessage());
			}
			
			finally
			{
				//clean and close resources by closing connection to file
				//ปิด scanner 
				scanner.close();
				System.out.println("Finally, closing file connection");
			}
			catch(MyIOException e)
			{
			System.out.println(e.getMessage() + "\n" + e.getErrorTime().toLocaleString() + "," + e.getErrorFile().getName());	
			}
	}
}
